# TestNG_Study
testng study
Reference resources： http://www.yiibai.com/html/testng/2013/0913292.html